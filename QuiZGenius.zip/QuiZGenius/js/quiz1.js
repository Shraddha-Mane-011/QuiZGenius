// creating an array and passing the number, questions, options, and answers
//Computer and technology
const questions = [
    {
   
    question: "What does CPU stand for?",
    answer: "Central Processing Unit",
    options: [
      "Central Processing Unit",
      "Computer Personal Unit",
      "Central Process Unit",
      "Central Program Unit"
     
    ]
  },
    {
  
    question: "Which programming language is often used for web development?",
    answer: "JavaScript",
    options: [
      "Java",
      "Python",
      "JavaScript",
      "C++"

    ]
  },
    {
  
    question: "Which company developed the Java programming language?",
    answer: "Sun Microsystems (now Oracle)",
    options: [
      "Microsoft",
      "Apple",
      "Sun Microsystems (now Oracle)",
      "IBM"

    ]
  },
    {
   
    question: "What does HTML stand for in web development?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Markup Language",
      "Hyper Transfer Markup Language",
      "High Text Markup Language",
      "Hyperlink and Text Markup Language"

    ]
  },
    {
  
    question: "What is the function of RAM in a computer?",
    answer: "Temporary storage of data that the CPU is currently working on",
    options: [
      "Long-term storage of data",
      "Temporary storage of data that the CPU is currently working on",
      "Displaying graphics on the screen",
      "Cooling the CPU"

    ]
  },

  {
  
    question: "Which of the following is not a popular operating system?",
    answer: "Java",
    options: [
      "Windows",
      "macOS",
      "Linux",
      "Java"

    ]
  },

  {
   
    question: "Which technology allows wireless communication between devices over short distances?",
    answer: "Wi-Fi",
    options: [
      "Bluetooth",
      "Wi-Fi",
      "Ethernet",
      "USB"
      
    ]
  },

  {
   
    question: "What does URL stand for in the context of the internet?",
    answer: "Universal Resource Locator",
    options: [
      "Universal Resource Locator",
      "Uniform Retrieval Language",
      "Uniform Resource Location",
      "Universal Retrieval Link"
     
    ]
  },
  
  {
   
    question: " What is the main purpose of an operating system?",
    answer: "Managing hardware resources and providing user interfaces",
    options: [
      "Storing files",
      "Managing hardware resources and providing user interfaces",
      "Browsing the internet",
      "Word processing"

    ]
  },
  
  {
   
    question: "Which of the following is not a type of computer virus?",
    answer: "Firewall",
    options: [
      "Trojan Horse",
      "Worm",
      "Firewall",
      "Spyware"
     
    ]
  },

  {
   
    question: "What is the primary function of an antivirus software?",
    answer: "Protecting your computer from malware and viruses",
    options: [
      "Speeding up your computer",
      "Protecting your computer from malware and viruses",
      "Creating backups of your data",
      "Managing your emails"
      
    ]
  }, 
  
  {
  
    question: "Which cloud storage service is developed by Google?",
    answer: "Google Drive",
    options: [
      "iCloud",
      "Dropbox",
      "Google Drive",
      "OneDrive"
      
    ]
  },

  {
    
    question: "What does the acronym 'IoT' stand for?",
    answer: "Internet of Things",
    options: [
      "Internet of Text",
      "Internet of Things",
      "Information on Time",
      "International Organization of Technology"
      
    ]
  },

  {
   
    question: "What does the acronym 'HTTP' stand for in website URLs?",
    answer: "Hypertext Transfer Protocol",
    options: [
      "Hyper Transfer Text Protocol",
      "Hypertext Transfer Protocol",
      "High Tech Text Processing",
      "Hypertext Time Protocol"
     
    ]
  },

  {
   
    question: "Which programming language is commonly used for data analysis and machine learning?",
    answer:  "R",
    options: [
      "Ruby",
      "C#",
      "R",
      "Swift"
      
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}

