// creating an array and passing the number, questions, options, and answers
//finance and economics
const questions = [
    {
    numb: 1,
    question: "What does GDP stand for in economics?",
    answer: "Gross Domestic Product",
    options: [
        "Gross Domestic Product",
        "Good Distribution Policy",
        "General Development Plan",
        "Government Debt Payment"  
        
    ]
  },
    {
    numb: 2,
    question: "What is the term for a situation where prices for goods and services rise, leading to a decrease in the purchasing power of a currency?",
    answer: "Inflation",
    options: [
        "Inflation",
        "Recession",
        "Deflation",
        "Stagflation"
        
    ]
  },
    {
    numb: 3,
    question: "Which type of unemployment occurs when a person is temporarily out of work and actively seeking a job?",
    answer: "Frictional unemployment",
    options: [
        "Cyclical unemployment",
        "Structural unemployment",
        "Frictional unemployment",
        "Seasonal unemployment"
        
    ]
  },
    {
    numb: 4,
    question: "What economic term describes a period of negative economic growth that lasts for an extended period?",
    answer: "Depression",
    options: [
        "Depression",
        "Boom",
        "Expansion",
        "Prosperity"
    ]
  },
    {
    numb: 5,
    question: "Which economic concept measures the responsiveness of the quantity demanded of a good to a change in its price?",
    answer: "Elasticity",
    options: [
        "Elasticity",
        "Utility",
        "Monopoly",
        "Surplus"
        
    ]
  },

  {
    numb: 6,
    question: "In the context of international trade, what does the term 'trade deficit' mean?",
    answer: "A country imports more goods than it exports.",
    options: [
        "A country exports more goods than it imports.",
        "A country imports more goods than it exports.",
        "A country's currency is strong.",
        "A country's currency is weak."
       
    ]
  },

  {
    numb: 7,
    question: "Which economic theory suggests that the government should play a limited role in regulating and controlling the economy?",
    answer: "Supply-side economics",
    options: [
        "Keynesian economics",
        "Monetarism",
        "Supply-side economics",
        "Command economy"  
       
    ]
  },

  {
    numb: 8,
    question: "What is the term for the total amount of money a business takes in by selling goods or services?",
    answer: "Revenue",
    options: [
      "Revenue",
      "Profit",
      "Investment",
      "Debt"
     
    ]
  },
  
  {
    numb: 9,
    question: "Which of the following is an example of a regressive tax?",
    answer: "Sales tax",
    options: [
        "Sales tax",
        "Progressive income tax",
        "Property tax",
        "Value-added tax (VAT)"
      
    ]
  },
  
  {
    numb: 10,
    question: "What is the primary goal of monetary policy set by a central bank, such as the Federal Reserve in the United States?",
    answer: "Promoting economic growth",
    options: [
        "Reducing inflation",
        "Maximizing government revenue",
        "Promoting economic growth",
        "Controlling the money supply"
    
    ]
  },

  {
    numb: 11,
    question: "What is the term for money that is earned through work or received as an allowance or gift?",
    answer: "Income",
    options: [
        "Salary",
        "Investment",
        "Income",
        "Loan"    
        
    ]
  }, 
  
  {
    numb: 12,
    question: " What is the basic concept of economics that refers to using resources to produce goods and services?",
    answer: "Production",
    options: [
        "Consumption",
        "Distribution",
        "Production",
        "Savings" 
     
    ]
  },

  {
    numb: 13,
    question: "Which of the following is considered a type of financial institution where you can save or deposit money and earn interest?",
    answer: "Bank",
    options: [
        "Library",
        "Bank",
        "Park",
        "School"  
       
    ]
  },

  {
    numb: 14,
    question: "What is the term for goods and services that are bought and used by people to satisfy their needs and wants?",
    answer: "Consumption",
    options: [
        "Savings",
        "Demand",
        "Supply",
        "Consumption" 
       
    ]
  },

  {
    numb: 15,
    question: "Which of the following is an example of a durable good?",
    answer: "Bicycle",
    options: [
        "Bread",
        "Bicycle",
        "Ice cream",
        "Newspaper"
    
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}


