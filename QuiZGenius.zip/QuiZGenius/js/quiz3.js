// creating an array and passing the number, questions, options, and answers
//Robotics
const questions = [
    {
    numb: 1,
    question: "What does the term 'AI' stand for in the context of robotics?",
    answer: "Artificial Intelligence",
    options: [
        "Advanced Interaction",
        "Artificial Intelligence",
        "Automated Integration",
        "Autonomous Interface"  
    ]
  },
    {
    numb: 2,
    question: "What type of robot is designed to perform tasks in environments too dangerous for humans, such as in radioactive environments?",
    answer: "Hazardous Environment Robot",
    options: [
        "Industrial Robot",
        "Service Robot",
        "Military Robot",
        "Hazardous Environment Robot"
    ]
  },
    {
    numb: 3,
    question: "Which component of a robot is responsible for processing sensory information and making decisions?",
    answer: "Controller",
    options: [
        "Actuator",
        "Sensor",
        "Controller",
        "Manipulator"
    
    ]
  },
    {
    numb: 4,
    question: "What is the term for the process of a robot learning from its own experiences and improving its performance over time?",
    answer: "Machine Learning",
    options: [
        "Robotics Evolution",
        "Machine Learning",
        "Artificial Cognition",
        "Self-Assembly"
     

    ]
  },
    {
    numb: 5,
    question: "In robotics, what does the acronym 'LIDAR' stand for?",
    answer: "Light Detection and Ranging",
    options: [
        "Laser Identification Device for Autonomous Robots",
        "Light Detection and Ranging",
        "Land Information Data Acquisition and Retrieval",
        "Linear Integrated Detection and Response"
    ]
  },

  {
    numb: 6,
    question: "Which famous robotics company is known for its Roomba series of vacuum cleaning robots?",
    answer: "iRobot",
    options: [
        "Boston Dynamics",
        "Hanson Robotics",
        "iRobot",
        "ABB Robotics"
     

    ]
  },

  {
    numb: 7,
    question: "What is the primary function of a robotic arm, also known as a manipulator?",
    answer: "To perform tasks and manipulate objects",
    options: [
        "To process sensory information",
        "To provide power to the robot",
        "To perform tasks and manipulate objects",
        "To control the robot's movement"  
    ]
  },

  {
    numb: 8,
    question: "Which programming language is commonly used for programming robots and automation systems?",
    answer: "RoboScript",
    options: [
      "Java",
      "Python",
      "C++",
      "RoboScript"
    ]
  },
  
  {
    numb: 9,
    question: "Which type of robot is typically used for tasks like welding, painting, and assembly in manufacturing?",
    answer: "Industrial Robot",
    options: [
        "Humanoid Robot",
        "Service Robot",
        "Industrial Robot",
        "Drone"
    ]
  },
  
  {
    numb: 10,
    question: "What is the term for a robot's ability to sense its surroundings and respond to changes in its environment?",
    answer: "Perception",
    options: [
        "Autonomy",
        "Adaptability",
        "Perception",
        "Navigation"
       
    ]
  },

  {
    numb: 11,
    question: "In robotics, what does the term 'ROS' stand for?",
    answer: "Robotic Operating System",
    options: [
        "Robotic Operating System",
        "Robot's Online Services",
        "Remote Operation Software",
        "Robotic Observation System"    
    ]
  }, 
  
  {
    numb: 12,
    question: "What type of robot is designed to assist or entertain humans, such as the ASIMO robot developed by Honda?",
    answer: " Service Robot",
    options: [
        "Service Robot",
        "Industrial Robot",
        "Military Robot",
        "Medical Robot"  
    ]
  },

  {
    numb: 13,
    question: "Which country is known for its advancements in humanoid robot technology and is home to the ASIMO robot?",
    answer: "Japan",
    options: [
        "Japan",
        "United States",
        "South Korea",
        "Germany"  
    ]
  },

  {
    numb: 14,
    question: "Which famous robotics company is known for its development of robots with lifelike movements, such as the Spot robot?",
    answer: "Boston Dynamics",
    options: [
        "Honda",
        "Boston Dynamics",
        "ABB Robotics",
        "Hanson Robotics" 
    ]
  },

  {
    numb: 15,
    question: "In robotics, what is the primary purpose of a sensor?",
    answer: "To gather data about the robot's surroundings",
    options: [
        "To generate power for the robot",
        "To control the robot's movement",
        "To process information and make decisions",
        "To gather data about the robot's surroundings"
    
      
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}