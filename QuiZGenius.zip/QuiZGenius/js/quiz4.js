// creating an array and passing the number, questions, options, and answers
//Art and movie
const questions = [
    {
    
    question: "Who painted the Mona Lisa?",
    answer: "Leonardo da Vinci",
    options: [
      "Vincent van Gogh",
      "Leonardo da Vinci",
      "Pablo Picasso",
      "Michelangelo"
      
    ]
  },
    {
  
    question: "What is the name of the famous painting with melting clocks, created by Salvador Dalí?",
    answer: "The Persistence of Memory",
    options: [
      "Starry Night",
      "The Persistence of Memory",
      "The Last Supper",
      "The Scream"

    ]
  },
    {
   
    question: "Which artist is known for his 'Campbell's Soup Cans' artwork?",
    answer: "Andy Warhol",
    options: [
      "Vincent van Gogh",
      "Andy Warhol",
      "Claude Monet",
      "Pablo Picasso"
    
    ]
  },
    {
    
    question: "What is a famous sculpture by Michelangelo depicting the biblical figure David?",
    answer: "David",
    options: [
      "The Thinker",
      "The Scream",
      "David",
      "Venus de Milo"
     
    ]
  },
    {
    
    question: "Who is famous for painting 'Starry Night'?",
    answer: "Vincent van Gogh",
    options: [
      "Leonardo da Vinci",
      "Vincent van Gogh",
      "Rembrandt",
      "Georgia O'Keeffe"
     
    ]
  },

  {
    
    question: "What art movement is characterized by vivid colors, bold shapes, and distorted imagery, often with a dreamlike quality?",
    answer: "Surrealism",
    options: [
      "Impressionism",
      "Cubism",
      "Surrealism",
      "Abstract Expressionism"
      
    ]
  },

  {
    
    question: "What is the name of the painting featuring a woman with a mysterious smile, created by Leonardo da Vinci?",
    answer: "The Mona Lisa",
    options: [
      "The Last Supper",
      "Starry Night",
      "The Girl with a Pearl Earring",
      "The Mona Lisa"

    ]
  },

  {
    
    question: "Which art form involves cutting and pasting paper to create designs and images?",
    answer: "Collage",
    options: [
      "Collage",
      "Sculpture",
      "Watercolor",
      "Calligraphy"
     
    ]
  },
  
  {
   
    question: " Who is famous for his 'Water Lilies' series of paintings?",
    answer: "Claude Monet",
    options: [
      "Claude Monet",
      "Jackson Pollock",
      "Henri Matisse",
      "Pablo Picasso"
      
    ]
  },
  
  {
    
    question: "Which artist is known for creating 'The Scream'?",
    answer: "Edvard Munch",
    options: [
      "Salvador Dalí",
      "Pablo Picasso",
      "Edvard Munch",
      "Vincent van Gogh"
   
    ]
  },

  {
    
    question: "What is the lowest-pitched woodwind instrument in an orchestra?",
    answer: "Bassoon",
    options: [
      "Trumpet",
      "Flute",
      "Clarinet",
      "Bassoon"
     
    ]
  }, 
  
  {
    
    question: "Who is often referred to as the 'King of Pop'?",
    answer: "Michael Jackson",
    options: [
      "Elvis Presley",
      "Michael Jackson",
      "Frank Sinatra",
      "The Beatles"
     
    ]
  },

  {
    
    question: "Which of the following is a string instrument played with a bow?",
    answer: "Violin",
    options: [
      "Trumpet",
      "Piano",
      "Violin",
      "Flute"

    ]
  },

  {
    
    question: "Which musical term describes a gradual increase in loudness?",
    answer: "Crescendo",
    options: [
      "Crescendo",
      "Decrescendo",
      "Allegro",
      "Adagio"
      
    ]
  },

  {
    
    question: "What is the standard number of strings on a classical guitar?",
    answer: "6",
    options: [
      "4",
      "5",
      "6",
      "7"
     
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}


