// creating an array and passing the number, questions, options, and answers
//Sports
const questions = [
    {
    numb: 1,
    question: "In which sport is the term 'slam dunk' commonly used?",
    answer: "Basketball",
    options: [
        "Soccer",
        "Tennis",
        "Basketball",
        "Golf"  
       
    ]
  },
    {
    numb: 2,
    question: " What is the highest possible score in a single frame of a game of bowling?",
    answer: "300",
    options: [
        "10",
        "100",
        "300",
        "50"

    ]
  },
    {
    numb: 3,
    question: "Who is known as 'The Great One' in the sport of ice hockey?",
    answer: "Wayne Gretzky",
    options: [
        "Wayne Gretzky",
        "Mario Lemieux",
        "Sidney Crosby",
        "Bobby Orr"

    ]
  },
    {
    numb: 4,
    question: "Which country won the FIFA World Cup in 2018?",
    answer: "France",
    options: [
        "Brazil",
        "Germany",
        "France",
        "Argentina"
    
    ]
  },
    {
    numb: 5,
    question: "What is the standard number of players on a soccer (football) team on the field at the same time?",
    answer: "11",
    options: [
        "8",
        "10",
        "11",
        "12"
    
    ]
  },

  {
    numb: 6,
    question: "Which sport features terms like 'birdie' and 'eagle'?",
    answer: "Golf",
    options: [
        "Tennis",
        "Golf",
        "Table Tennis",
        "Badminton"
       
    ]
  },

  {
    numb: 7,
    question: "In baseball, what is the term for a batter hitting the ball over the outfield fence for a home run?",
    answer: "Homerun",
    options: [
        "Touchdown",
        "Slam Dunk",
        "Grand Slam",
        "Homerun"  
    
    ]
  },

  {
    numb: 8,
    question: "What sport is known as the 'Sport of Kings'?",
    answer: "Polo",
    options: [
      "Polo",
      "Cricket",
      "Tennis",
      "Chess"
      
    ]
  },
  
  {
    numb: 9,
    question: " Which athlete is often referred to as 'The Fastest Man on Earth'?",
    answer: "Usain Bolt",
    options: [
        "Usain Bolt",
        "Carl Lewis",
        "Jesse Owens",
        "Michael Johnson"
     
    ]
  },
  
  {
    numb: 10,
    question: "What is the object of the game of table tennis (ping pong)?",
    answer: "Score points by hitting the ball over the net and into the opponent's side",
    options: [
        "Score goals with a ball",
        "Score tries by carrying the ball into the end zone",
        "Score points by hitting the ball over the net and into the opponent's side",
        "Sink balls into pockets"
    
    ]
  },

  {
    numb: 11,
    question: "Which team sport is known for its 'Hail Mary' passes and end zone touchdowns?",
    answer: "American Football",
    options: [
        "Basketball",
        "Soccer",
        "American Football",
        "Rugby"    
    
    ]
  }, 
  
  {
    numb: 12,
    question: " What sport is the focus of the annual event known as '/The Masters'?",
    answer: "Golf",
    options: [
        "Golf",
        "Tennis",
        "Formula 1 Racing",
        "Ice Hockey" 
    
    ]
  },

  {
    numb: 13,
    question: "In Basket Ball how many points is a three point shot worth?",
    answer: "3",
    options: [
        "1",
        "2",
        "3",
        "4"  
    
    ]
  },

  {
    numb: 14,
    question: "Who is the most decorated Olympian of all time with 23 gold medals in swimming?",
    answer: "Michael Phelps",
    options: [
        "Michael Phelps",
        "Usain Bolt",
        "Jesse Owens",
        "Nadia Comăneci" 
    
    ]
  },

  {
    numb: 15,
    question: "What sport uses terms like 'deuce,' 'love,' and 'break point'?",
    answer: "Tennis",
    options: [
        "Tennis",
        "Badminton",
        "Cricket",
        "Archery"
    
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}


/*







**/