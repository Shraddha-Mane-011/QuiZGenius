// creating an array and passing the number, questions, options, and answers
//General Knowledge
const questions = [
    {
    numb: 1,
    question: "Who is the current President of the United States (as of September 2021)?",
    answer: "Joe Biden",
    options: [
        "Joe Biden",
        "Donald Trump",
        "Barack Obama",
        "George W. Bush"
    ]
  },
    {
    numb: 2,
    question: "Which country hosted the 2020 Summer Olympics (postponed to 2021)?",
    answer: "Japan",
    options: [
        "Japan",
        "China",
        "Brazil",
        "South Korea"

    ]
  },
    {
    numb: 3,
    question: "In 2021, which company became the first in the world to reach a market capitalization of $2 trillion?",
    answer: "Apple",
    options: [
        "Apple",
        "Amazon",
        "Microsoft",
        "Alphabet (Google)" 
    ]
  },
    {
    numb: 4,
    question: "Which global health crisis significantly impacted the world in 2020 and 2021, leading to widespread illness, travel restrictions, and vaccination campaigns?",
    answer: "COVID-19 (Coronavirus)",
    options: [
        "Swine Flu",
        "Zika Virus",
        "COVID-19 (Coronavirus)",
        "Ebola"
    ]
  },
    {
    numb: 5,
    question: "Which river is the longest in the world?",
    answer: "Nile",
    options: [
        "Nile",
        "Amazon",
        "Yangtze",
        "Mississippi" 
    ]
  },

  {
    numb: 6,
    question: "Which mountain range is often referred to as the 'Roof of the World' and is home to Mount Everest, the world's highest peak?",
    answer: "Himalayas",
    options: [
        "Andes",
        "Rocky Mountains",
        "Himalayas",
        "Alps"
    ]
  },

  {
    numb: 7,
    question: "The Sahara Desert is primarily located in which continent?",
    answer: " Africa",
    options: [
        "Asia",
        "Africa",
        "South America",
        "Australia"
    ]
  },

  {
    numb: 8,
    question: "Who is known for discovering America in 1492?",
    answer: "Christopher Columbus",
    options: [
        "Christopher Columbus",
        "Marco Polo",
        "Ferdinand Magellan",
        "Vasco da Gama"  
    ]
  },
  
  {
    numb: 9,
    question: "The American Civil War took place between which two groups in the 1860s?",
    answer: "The Union (North) and the Confederacy (South)",
    options: [
        "North and South Korea",
        "England and France",
        "The Union (North) and the Confederacy (South)",
        "Russia and the Ottoman Empire"
    ]
  },
  
  {
    numb: 10,
    question: "What is the largest ocean in the world?",
    answer: "Pacific Ocean",
    options: [
        "Atlantic Ocean",
        "Indian Ocean",
        "Pacific Ocean",
        "Arctic Ocean"     
    ]
  },

  {
    numb: 11,
    question: "Which river is often referred to as 'The Nile of the Americas' and is the longest river in South America?",
    answer: "Amazon River",
    options: [
        "Mississippi River",
        "Amazon River",
        "Colorado River",
        "Yangtze River"
    ]
  }, 
  
  {
    numb: 12,
    question: "Which imaginary line runs around the Earth horizontally and divides it into the Northern and Southern Hemispheres?",
    answer: "Equator",
    options: [
        "Prime Meridian",
        "Equator",
        "Tropic of Cancer",
        "Arctic Circle"
    ]
  },

  {
    numb: 13,
    question: "Which continent is home to the Sahara Desert, the largest hot desert in the world?",
    answer: "Africa",
    options: [
        "South America",
        "Africa",
        "Asia",
        "North America",  
    ]
  },

  {
    numb: 14,
    question: "What is the name of the world's highest mountain, located in the Himalayas?",
    answer: "Mount Everest",
    options: [
        "Mount Kilimanjaro",
        "Mount Fuji",
        "Mount Everest",
        "Mount Vesuvius"
    ]
  },

  {
    numb: 15,
    question: "Which imaginary line divides the Earth into the Eastern and Western Hemispheres and passes through Greenwich, London?",
    answer: "Prime Meridian",
    options: [
        "Equator",
        "Tropic of Capricorn",
        "International Date Line",
        "Prime Meridian"   
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}