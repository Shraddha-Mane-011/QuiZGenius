// creating an array and passing the number, questions, options, and answers
//Science fiction
const questions = [
    {
    numb: 1,
    question: "What is the atomic number of carbon, which has six protons?",
    answer: "6",
    options: [
        "6",
        "12",
        "14",
        "8"  
       
    ]
  },
    {
    numb: 2,
    question: "Which subatomic particle carries a positive electric charge?",
    answer: "Protonn",
    options: [
        "Electron",
        "Neutron",
        "Proton",
        "Photon"
       
    ]
  },
    {
    numb: 3,
    question: "In the electromagnetic spectrum, which type of radiation has the shortest wavelength?",
    answer: "Gamma rays",
    options: [
        "Infrared",
        "Ultraviolet",
        "X-rays",
        "Gamma rays"
       
    ]
  },
    {
    numb: 4,
    question: "What is the process by which plants use sunlight to convert carbon dioxide and water into glucose and oxygen?",
    answer: "Photosynthesis",
    options: [
        "Photosynthesis",
        "Respiration",
        "Fermentation",
        "Digestion"
  
    ]
  },
    {
    numb: 5,
    question: "Which gas is responsible for the depletion of the ozone layer in the Earth's atmosphere?",
    answer: "Chlorofluorocarbons (CFCs)",
    options: [
        "Carbon Dioxide (CO2)",
        "Methane (CH4)",
        "Chlorofluorocarbons (CFCs)",
        "Oxygen (O2)"
   
    ]
  },

  {
    numb: 6,
    question: "What is the unit of electrical resistance?",
    answer: "Ohm",
    options: [
        "Watt",
        "Volt",
        "Ampere",
        "Ohm"
      
    ]
  },

  {
    numb: 7,
    question: "In which part of the human digestive system are most of the nutrients from food absorbed into the bloodstream?",
    answer: "Small intestine",
    options: [
        "Stomach",
        "Small intestine",
        "Large intestine",
        "Esophagus"  
   
    ]
  },

  {
    numb: 8,
    question: "Which of the following elements is a noble gas and is commonly used in lighting?",
    answer: "Neon",
    options: [
      "Helium",
      "Neon",
      "Argon",
      "Krypton"
  
    ]
  },
  
  {
    numb: 9,
    question: "What is the SI unit of force, commonly measured using a spring scale?",
    answer: "Newton",
    options: [
        "Joule",
        "Newton",
        "Watt",
        "Ohm"
      
    ]
  },
  
  {
    numb: 10,
    question: "Which theory in biology explains the process of evolution by natural selection?",
    answer: "Theory of Evolution",
    options: [
        "Theory of Relativity",
        "Quantum Theory",
        "Cell Theory",
        "Theory of Evolution"
    
           ]

  },

  {
    numb: 11,
    question: "Which gas do plants absorb from the air and release oxygen during photosynthesis?",
    answer: "Carbon Dioxide",
    options: [
        "Oxygen",
        "Carbon Dioxide",
        "Nitrogen",
        "Hydrogen"    
      
    ]
  }, 
  
  {
    numb: 12,
    question: " What is the force that pulls objects toward the center of the Earth called?",
    answer: "Gravity",
    options: [
        "Magnetism",
        "Gravity",
        "Friction",
        "Buoyancy" 
      
    ]
  },

  {
    numb: 13,
    question: "What is the process of a solid turning into a liquid called?",
    answer: "Melting",
    options: [
        "Condensation",
        "Evaporation",
        "Melting",
        "Freezing"  
      
    ]
  },

  {
    numb: 14,
    question: "Which gas is most abundant in the Earth's atmosphere?",
    answer: "Nitrogen",
    options: [
        "Oxygen",
        "Nitrogen",
        "Carbon Dioxide",
        "Hydrogen" 
    
    ]
  },

  {
    numb: 15,
    question: "What is the largest organ in the human body?",
    answer: "Skin",
    options: [
        "Heart",
        "Liver",
        "Skin",
        "Brain"
    
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}


/*


* */