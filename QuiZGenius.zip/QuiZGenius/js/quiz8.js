// creating an array and passing the number, questions, options, and answers
//Space exploration
const questions = [
    {
    numb: 1,
    question: "Who was the first human to walk on the moon during the Apollo 11 mission?",
    answer: "Neil Armstrong",
    options: [
        "Yuri Gagarin",
        "John Glenn",
        "Neil Armstrong",
        "Buzz Aldrin"  
    
    ]
  },
    {
    numb: 2,
    question: "What is the name of the largest planet in our solar system?",
    answer: "Jupiter",
    options: [
        "Mars",
        "Venus",
        "Jupiter",
        "Saturn"

    ]
  },
    {
    numb: 3,
    question: "Which spacecraft was the first to reach interstellar space, crossing the boundary of our solar system?",
    answer: "Voyager 1",
    options: [
        "Voyager 1",
        "Hubble Space Telescope",
        "Mars Rover",
        "Apollo 13"

    ]
  },
    {
    numb: 4,
    question: "What is the term for a space rock that enters Earth's atmosphere and burns up, creating a bright streak of light?",
    answer: "Meteor",
    options: [
        "Meteor",
        "Comet",
        "Asteroid",
        "Supernova"

    ]
  },
    {
    numb: 5,
    question: "Who is often referred to as the 'Father of Rocketry' and developed the first liquid-fueled rocket?",
    answer: "Robert H. Goddardy",
    options: [
        "Galileo Galilei",
        "Robert H. Goddard",
        "Konstantin Tsiolkovsky",
        "Werner von Braun"
    
    ]
  },

  {
    numb: 6,
    question: "What is the name of the spacecraft that successfully landed the first humans on the moon in 1969?",
    answer: "Apollo 11",
    options: [
        "Apollo 11",
        "Space Shuttle Challenger",
        "Skylab",
        "Mercury 7"
    
    ]
  },

  {
    numb: 7,
    question: "Which planet in our solar system is known as the 'Red Planet' due to its reddish appearance?",
    answer: "Mars",
    options: [
        "Venus",
        "Jupiter",
        "Mars",
        "Saturn"  
    
    ]
  },

  {
    numb: 8,
    question: "What is the name of the first artificial satellite launched into space by the Soviet Union in 1957?",
    answer: "Sputnik 1",
    options: [
      "Explorer 1",
      "Apollo 11",
      "Sputnik 1",
      "Hubble Space Telescope"

    ]
  },
  
  {
    numb: 9,
    question: "Which planet is known for its beautiful ring system?",
    answer: "Saturn",
    options: [
        "Mars",
        "Venus",
        "Saturn",
        "Uranus"
    
    ]
  },
  
  {
    numb: 10,
    question: "In space terminology, what does NASA stand for?",
    answer: "National Aeronautics and Space Administration",
    options: [
        "National Aeronautics and Space Administration",
        "North American Space Association",
        "National Aerospace and Space Agency",
        "New Astronomical Space Advancements"

    ]
  },

  {
    numb: 11,
    question: "What is the name of the rover that successfully explored the surface of Mars and transmitted valuable data back to Earth?",
    answer: "Curiosity",
    options: [
        "Curiosity",
        "Voyager",
        "Spirit",
        "Opportunity"    
    
    ]
  }, 
  
  {
    numb: 12,
    question: " Which space agency was responsible for the Apollo program that landed humans on the moon?",
    answer: "NASA (National Aeronautics and Space Administration)",
    options: [
        "ESA (European Space Agency)",
        "CNSA (China National Space Administration)",
        "NASA (National Aeronautics and Space Administration)",
        "Roscosmos (Russian Federal Space Agency)" 

    ]
  },

  {
    numb: 13,
    question: "What is the name of the powerful space telescope launched in 1990, providing stunning images of the universe?",
    answer: "Hubble Space Telescope",
    options: [
        "Kepler Space Telescope",
        "Hubble Space Telescope",
        "Chandra X-ray Observatory",
        "James Webb Space Telescope"  
     
    ]
  },

  {
    numb: 14,
    question: "Which gas is most abundant in the Earth's atmosphere?",
    answer:  "Nitrogen",
    options: [
        "Oxygen",
        "Nitrogen",
        "Carbon Dioxide",
        "Hydrogen" 
    
    ]
  },

  {
    numb: 15,
    question: "What is the name of the first American woman in space?",
    answer: "Sally Ride",
    options: [
        "Valentina Tereshkova",
        "Sally Ride",
        "Yuri Gagarin",
        "Mae Jemison"
    
    ]
  },
  
];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Shuffle the questions array to generate a random sequence
shuffleArray(questions);

// Example usage:
for (const question of questions) {
  console.log(question);
}



